-- ROWBOAT PORTAL EXTENSION
-- Run this once in Supabase SQL Editor after the existing schema.sql.
-- Adds candidate/employer profiles, employer job approval, and candidate ownership.
-- No secrets are required in this file.

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(auth.jwt() -> 'app_metadata' ->> 'role', '') = 'admin';
$$;

alter table public.jobs add column if not exists created_by uuid references auth.users(id) on delete set null;
alter table public.jobs add column if not exists approval_status text not null default 'approved' check (approval_status in ('pending','approved','rejected'));
update public.jobs set approval_status = 'approved' where approval_status is null;
create index if not exists jobs_created_by_idx on public.jobs(created_by);
create index if not exists jobs_approval_status_idx on public.jobs(approval_status);

alter table public.rowboat_applications add column if not exists candidate_id uuid references auth.users(id) on delete set null;
create index if not exists rowboat_applications_candidate_id_idx on public.rowboat_applications(candidate_id);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  resume_url text,
  linkedin_url text,
  company_name text,
  company_website text,
  role text not null default 'candidate' check (role in ('candidate','employer','admin')),
  employer_status text not null default 'not_requested' check (employer_status in ('not_requested','pending','approved','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists profiles_role_idx on public.profiles(role);
create index if not exists profiles_employer_status_idx on public.profiles(employer_status);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  requested_role text := coalesce(new.raw_user_meta_data ->> 'requested_role', 'candidate');
  safe_role text := case when requested_role = 'employer' then 'employer' else 'candidate' end;
begin
  insert into public.profiles (id, full_name, role, employer_status)
  values (
    new.id,
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'full_name', '')), ''),
    safe_role,
    case when safe_role = 'employer' then 'pending' else 'not_requested' end
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_rowboat_profile on auth.users;
create trigger on_auth_user_created_rowboat_profile
after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.protect_profile_roles()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    new.role := old.role;
    new.employer_status := old.employer_status;
  end if;
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists profiles_protect_roles on public.profiles;
create trigger profiles_protect_roles
before update on public.profiles
for each row execute function public.protect_profile_roles();

alter table public.profiles enable row level security;

grant select, insert, update on public.profiles to authenticated;

drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile"
on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());

drop policy if exists "Users can create own profile" on public.profiles;
create policy "Users can create own profile"
on public.profiles for insert to authenticated
with check (id = auth.uid() and role in ('candidate','employer') and employer_status in ('not_requested','pending'));

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
on public.profiles for update to authenticated
using (id = auth.uid() or public.is_admin())
with check (id = auth.uid() or public.is_admin());

-- Existing rows are treated as approved admin-created jobs. Employer-created jobs
-- are added with created_by = auth.uid() and approval_status = pending.
alter table public.jobs enable row level security;

drop policy if exists "Public can read open jobs" on public.jobs;
create policy "Public can read open jobs"
on public.jobs for select to anon, authenticated
using (status = 'open' and approval_status = 'approved');

drop policy if exists "Admin can read all jobs" on public.jobs;
create policy "Admin can read all jobs"
on public.jobs for select to authenticated
using (public.is_admin());

drop policy if exists "Employer can read own jobs" on public.jobs;
create policy "Employer can read own jobs"
on public.jobs for select to authenticated
using (created_by = auth.uid());

drop policy if exists "Admin can insert jobs" on public.jobs;
create policy "Admin can insert jobs"
on public.jobs for insert to authenticated
with check (public.is_admin());

drop policy if exists "Employer can insert jobs" on public.jobs;
create policy "Employer can insert jobs"
on public.jobs for insert to authenticated
with check (created_by = auth.uid() and approval_status = 'pending' and status = 'draft');

drop policy if exists "Admin can update jobs" on public.jobs;
create policy "Admin can update jobs"
on public.jobs for update to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "Employer can update own jobs" on public.jobs;
create policy "Employer can update own jobs"
on public.jobs for update to authenticated
using (created_by = auth.uid())
with check (created_by = auth.uid() and approval_status = 'pending' and status = 'draft');

drop policy if exists "Admin can delete jobs" on public.jobs;
create policy "Admin can delete jobs"
on public.jobs for delete to authenticated
using (public.is_admin());

drop policy if exists "Employer can delete own jobs" on public.jobs;
create policy "Employer can delete own jobs"
on public.jobs for delete to authenticated
using (created_by = auth.uid());

-- Candidate applications are public, but when authenticated we attach the account id.
alter table public.rowboat_applications enable row level security;

grant select, update, delete on public.rowboat_applications to authenticated;
grant insert on public.rowboat_applications to anon, authenticated;

drop policy if exists "Public can submit rowboat applications" on public.rowboat_applications;
create policy "Public can submit rowboat applications"
on public.rowboat_applications for insert to anon, authenticated
with check (candidate_id is null or candidate_id = auth.uid());

drop policy if exists "Admin can view rowboat applications" on public.rowboat_applications;
create policy "Admin can view rowboat applications"
on public.rowboat_applications for select to authenticated
using (public.is_admin());

drop policy if exists "Candidate can view own applications" on public.rowboat_applications;
create policy "Candidate can view own applications"
on public.rowboat_applications for select to authenticated
using (candidate_id = auth.uid());

drop policy if exists "Employer can view applications to own jobs" on public.rowboat_applications;
create policy "Employer can view applications to own jobs"
on public.rowboat_applications for select to authenticated
using (exists (select 1 from public.jobs j where j.id = rowboat_applications.job_id and j.created_by = auth.uid()));

drop policy if exists "Admin can update rowboat applications" on public.rowboat_applications;
create policy "Admin can update rowboat applications"
on public.rowboat_applications for update to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "Employer can update applications to own jobs" on public.rowboat_applications;
create policy "Employer can update applications to own jobs"
on public.rowboat_applications for update to authenticated
using (exists (select 1 from public.jobs j where j.id = rowboat_applications.job_id and j.created_by = auth.uid()))
with check (exists (select 1 from public.jobs j where j.id = rowboat_applications.job_id and j.created_by = auth.uid()));

drop policy if exists "Admin can delete rowboat applications" on public.rowboat_applications;
create policy "Admin can delete rowboat applications"
on public.rowboat_applications for delete to authenticated
using (public.is_admin());

drop policy if exists "Employer can delete applications to own jobs" on public.rowboat_applications;
create policy "Employer can delete applications to own jobs"
on public.rowboat_applications for delete to authenticated
using (exists (select 1 from public.jobs j where j.id = rowboat_applications.job_id and j.created_by = auth.uid()));

-- Keep updated_at accurate on profiles too.
drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

-- Private candidate resume storage. Uploads are owned by candidates and are
-- accessed through /api/resumes, which returns short-lived signed URLs after
-- checking candidate/employer/admin authorization.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'candidate-resumes',
  'candidate-resumes',
  false,
  10485760,
  array['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document']
)
on conflict (id) do update set
  public = false,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Candidates can upload own resumes" on storage.objects;
create policy "Candidates can upload own resumes"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'candidate-resumes'
  and name like 'candidate-resumes/' || auth.uid()::text || '/%'
);

drop policy if exists "Candidates can replace own resumes" on storage.objects;
create policy "Candidates can replace own resumes"
on storage.objects for update to authenticated
using (
  bucket_id = 'candidate-resumes'
  and name like 'candidate-resumes/' || auth.uid()::text || '/%'
)
with check (
  bucket_id = 'candidate-resumes'
  and name like 'candidate-resumes/' || auth.uid()::text || '/%'
);

drop policy if exists "Candidates can delete own resumes" on storage.objects;
create policy "Candidates can delete own resumes"
on storage.objects for delete to authenticated
using (
  bucket_id = 'candidate-resumes'
  and name like 'candidate-resumes/' || auth.uid()::text || '/%'
);

drop policy if exists "Authorized users can read candidate resumes" on storage.objects;
create policy "Authorized users can read candidate resumes"
on storage.objects for select to authenticated
using (
  bucket_id = 'candidate-resumes'
  and (
    public.is_admin()
    or name like 'candidate-resumes/' || auth.uid()::text || '/%'
    or exists (
      select 1
      from public.rowboat_applications a
      join public.jobs j on j.id = a.job_id
      where j.created_by = auth.uid()
        and a.resume_url = 'storage:' || name
    )
  )
);
