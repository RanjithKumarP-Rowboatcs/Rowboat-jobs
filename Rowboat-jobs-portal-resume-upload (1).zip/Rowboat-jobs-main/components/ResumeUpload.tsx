'use client'

import { useRef, useState } from 'react'
import { createClient } from '../lib/supabase/browser'

const BUCKET = 'candidate-resumes'
const MAX_SIZE = 10 * 1024 * 1024
const ALLOWED = new Set([
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
])

function safeFileName(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '') || 'resume'
}

export default function ResumeUpload({ value, onUploaded }: { value?: string; onUploaded: (value: string) => void | Promise<void> }) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [fileName, setFileName] = useState('')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  async function upload() {
    const file = inputRef.current?.files?.[0]
    setError('')
    setMessage('')
    if (!file) {
      setError('Choose a PDF, DOC or DOCX resume first.')
      return
    }
    if (!ALLOWED.has(file.type)) {
      setError('Only PDF, DOC and DOCX resumes are supported.')
      return
    }
    if (file.size > MAX_SIZE) {
      setError('The resume must be 10 MB or smaller.')
      return
    }

    setBusy(true)
    try {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error('Please sign in before uploading a resume.')

      const unique = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`
      const path = `candidate-resumes/${user.id}/${unique}-${safeFileName(file.name)}`
      const { error: uploadError } = await supabase.storage.from(BUCKET).upload(path, file, {
        contentType: file.type,
        upsert: false,
      })
      if (uploadError) throw uploadError

      await onUploaded(`storage:${path}`)
      setFileName(file.name)
      setMessage('Resume uploaded successfully.')
      if (inputRef.current) inputRef.current.value = ''
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to upload resume.')
    } finally {
      setBusy(false)
    }
  }

  const currentUploaded = value?.startsWith('storage:')

  return (
    <div className="resumeUpload">
      <div className="resumeUploadRow">
        <input ref={inputRef} type="file" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" onChange={e => setFileName(e.target.files?.[0]?.name || '')} />
        <button type="button" className="secondaryUploadButton" onClick={upload} disabled={busy}>
          {busy ? 'Uploading…' : 'Upload resume'}
        </button>
      </div>
      <span className="resumeUploadHint">Choose from Desktop, Downloads or another folder. PDF, DOC or DOCX up to 10 MB.</span>
      {fileName && <span className="resumeUploadName">Selected: {fileName}</span>}
      {currentUploaded && !fileName && <span className="resumeUploadName">A resume is already uploaded to your profile.</span>}
      {message && <span className="resumeUploadMessage">{message}</span>}
      {error && <span className="resumeUploadError">{error}</span>}
    </div>
  )
}
