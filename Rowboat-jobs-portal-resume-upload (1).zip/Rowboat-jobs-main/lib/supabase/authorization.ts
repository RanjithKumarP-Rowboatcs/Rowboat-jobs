import { createClient } from './server'

export type PortalRole = 'candidate' | 'employer' | 'admin'

export async function getAuthContext() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { supabase, user: null, role: null as PortalRole | null, profile: null }

  if (user.app_metadata?.role === 'admin') {
    return { supabase, user, role: 'admin' as const, profile: null }
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('id,full_name,phone,resume_url,linkedin_url,company_name,company_website,role,employer_status,created_at,updated_at')
    .eq('id', user.id)
    .maybeSingle()

  const role: PortalRole = profile?.role === 'employer' ? 'employer' : 'candidate'
  return { supabase, user, role, profile }
}

export function isApprovedEmployer(role: PortalRole | null, profile: any) {
  return role === 'employer' && profile?.employer_status === 'approved'
}
