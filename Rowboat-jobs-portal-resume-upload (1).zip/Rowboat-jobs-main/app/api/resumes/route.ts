import { NextRequest, NextResponse } from 'next/server'
import { getAuthContext } from '../../../lib/supabase/authorization'

export const dynamic = 'force-dynamic'

const BUCKET = 'candidate-resumes'
const PREFIX = 'storage:candidate-resumes/'

export async function GET(request: NextRequest) {
  const rawPath = request.nextUrl.searchParams.get('path') || ''
  if (!rawPath.startsWith(PREFIX)) return NextResponse.json({ error: 'Invalid resume path' }, { status: 400 })

  const path = rawPath.slice('storage:'.length)
  const { supabase, user, role } = await getAuthContext()
  if (!user) return NextResponse.json({ error: 'Sign in required' }, { status: 401 })

  if (role === 'candidate' && !path.startsWith(`candidate-resumes/${user.id}/`)) {
    return NextResponse.json({ error: 'Not authorized' }, { status: 403 })
  }

  if (role === 'employer') {
    const { data: application } = await supabase
      .from('rowboat_applications')
      .select('id,job_id,resume_url,jobs!inner(created_by)')
      .eq('resume_url', rawPath)
      .eq('jobs.created_by', user.id)
      .maybeSingle()
    if (!application) return NextResponse.json({ error: 'Not authorized' }, { status: 403 })
  }

  if (role !== 'admin' && role !== 'candidate' && role !== 'employer') {
    return NextResponse.json({ error: 'Not authorized' }, { status: 403 })
  }

  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, 60 * 10)
  if (error || !data?.signedUrl) return NextResponse.json({ error: error?.message || 'Unable to open resume' }, { status: 404 })

  return NextResponse.redirect(data.signedUrl, { status: 302 })
}
