'use client'

import { FormEvent, useEffect, useState } from 'react'
import { createClient } from '../../lib/supabase/browser'

const emptyJob = { title: '', company: '', module: 'SAP', industry: 'Information Technology', location: 'India', experience: '', type: 'Full-time', openings: 1, salary: '', description: '', requirements: '', responsibilities: '', skills: '', apply_email: 'ranjith@rowboatcs.com', reference_code: '', status: 'draft', approval_status: 'approved' }

type Employer = { id: string; full_name?: string; company_name?: string; company_website?: string; phone?: string; role: string; employer_status: string; created_at: string }

export default function AdminPage() {
  const [user, setUser] = useState<{ email?: string } | null>(null)
  const [jobs, setJobs] = useState<any[]>([])
  const [applications, setApplications] = useState<any[]>([])
  const [employers, setEmployers] = useState<Employer[]>([])
  const [job, setJob] = useState<any>(emptyJob)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [tab, setTab] = useState<'jobs' | 'applications' | 'employers'>('jobs')
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    const supabase = createClient()
    supabase.auth.getUser().then(({ data }) => setUser(data.user ? { email: data.user.email } : null))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUser(session?.user ? { email: session.user.email } : null))
    return () => listener.subscription.unsubscribe()
  }, [])

  async function load() {
    const [j, a, e] = await Promise.all([fetch('/api/jobs?admin=1'), fetch('/api/applications'), fetch('/api/admin/employers')])
    if (j.ok) setJobs((await j.json()).jobs || [])
    if (a.ok) setApplications((await a.json()).applications || [])
    if (e.ok) setEmployers((await e.json()).employers || [])
  }

  useEffect(() => { if (user) load() }, [user])

  if (!user) return <main className="adminShell"><div className="adminGate"><img src="/rowboat-logo.svg" alt="ROWBOAT CONSULTING SERVICES"/><h1>Admin access</h1><p>Sign in to publish requirements, approve employers and review candidate applications.</p><a className="adminButton" href="/admin/login">Sign in →</a></div></main>

  async function saveJob(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage('')
    const payload = { ...job, openings: Number(job.openings) || 1, skills: String(job.skills || '').split(',').map((s: string) => s.trim()).filter(Boolean) }
    const r = await fetch(editingId ? `/api/jobs/${editingId}` : '/api/jobs', { method: editingId ? 'PATCH' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    const b = await r.json()
    if (!r.ok) setMessage(b.error || 'Unable to save')
    else { setMessage(editingId ? 'Requirement updated.' : 'Requirement created.'); setJob(emptyJob); setEditingId(null); await load() }
    setBusy(false)
  }

  function editJob(item: any) { setEditingId(item.id); setJob({ ...item, skills: (item.skills || []).join(', '), approval_status: item.approval_status || 'approved' }); setTab('jobs'); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  async function removeJob(id: string) { if (!confirm('Delete this requirement?')) return; await fetch(`/api/jobs/${id}`, { method: 'DELETE' }); await load() }
  async function updateJobApproval(id: string, approval_status: 'approved' | 'rejected') {
    await fetch(`/api/jobs/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ approval_status, status: approval_status === 'approved' ? 'open' : 'closed' }) })
    await load()
  }
  async function setApplicationStatus(id: string, status: string) { await fetch(`/api/applications/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) }); await load() }
  async function setEmployerStatus(id: string, employer_status: string) { await fetch('/api/admin/employers', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, employer_status }) }); await load() }
  async function signOut() { const supabase = createClient(); await supabase.auth.signOut(); location.href = '/admin/login' }

  return <main className="adminShell"><header className="adminHeader"><a href="/"><img src="/rowboat-logo.svg" alt="ROWBOAT CONSULTING SERVICES"/></a><div><span>{user.email}</span><a className="headerPortalLink" href="/login">Portal</a><button onClick={signOut}>Sign out</button></div></header><section className="adminIntro"><div><div className="eyebrow">ROWBOAT ADMIN</div><h1>Manage the platform.</h1><p>Control jobs, employer approvals and candidate applications from one workspace.</p></div><a className="adminButton" href="/">View website →</a></section><nav className="adminTabs"><button className={tab==='jobs'?'active':''} onClick={()=>setTab('jobs')}>Requirements ({jobs.length})</button><button className={tab==='applications'?'active':''} onClick={()=>setTab('applications')}>Applications ({applications.length})</button><button className={tab==='employers'?'active':''} onClick={()=>setTab('employers')}>Employers ({employers.length})</button></nav>{tab==='jobs'&&<section className="adminGrid"><form className="adminForm" onSubmit={saveJob}><div className="formTitle"><h2>{editingId?'Edit requirement':'Add requirement'}</h2>{editingId&&<button type="button" onClick={()=>{setEditingId(null);setJob(emptyJob)}}>Cancel edit</button>}</div><label>Job title<input required value={job.title} onChange={e=>setJob({...job,title:e.target.value})}/></label><div className="two"><label>Company<input value={job.company} onChange={e=>setJob({...job,company:e.target.value})}/></label><label>Reference code<input value={job.reference_code} onChange={e=>setJob({...job,reference_code:e.target.value})}/></label></div><div className="two"><label>SAP module / category<input value={job.module} onChange={e=>setJob({...job,module:e.target.value})}/></label><label>Industry<input value={job.industry} onChange={e=>setJob({...job,industry:e.target.value})}/></label></div><div className="two"><label>Location<input value={job.location} onChange={e=>setJob({...job,location:e.target.value})}/></label><label>Experience<input value={job.experience} onChange={e=>setJob({...job,experience:e.target.value})}/></label></div><div className="three"><label>Type<select value={job.type} onChange={e=>setJob({...job,type:e.target.value})}><option>Full-time</option><option>Contract</option><option>Part-time</option><option>Remote</option></select></label><label>Openings<input type="number" min="1" value={job.openings} onChange={e=>setJob({...job,openings:e.target.value})}/></label><label>Status<select value={job.status} onChange={e=>setJob({...job,status:e.target.value})}><option value="draft">Draft</option><option value="open">Open</option><option value="closed">Closed</option></select></label></div><label>Salary / CTC<input value={job.salary} onChange={e=>setJob({...job,salary:e.target.value})}/></label><label>Skills <small>comma separated</small><input value={job.skills} onChange={e=>setJob({...job,skills:e.target.value})}/></label><label>Short description<textarea rows={4} value={job.description} onChange={e=>setJob({...job,description:e.target.value})}/></label><label>Requirements<textarea rows={6} value={job.requirements} onChange={e=>setJob({...job,requirements:e.target.value})}/></label><label>Responsibilities<textarea rows={6} value={job.responsibilities} onChange={e=>setJob({...job,responsibilities:e.target.value})}/></label><label>Application email<input type="email" value={job.apply_email} onChange={e=>setJob({...job,apply_email:e.target.value})}/></label>{message&&<div className="adminMessage">{message}</div>}<button className="adminButton" disabled={busy}>{busy?'Saving…':editingId?'Save changes →':'Create requirement →'}</button></form><div className="adminList"><h2>Requirements</h2>{jobs.length===0?<p>No requirements yet.</p>:jobs.map(item=><article className="adminJob" key={item.id}><div><div><span className={`status ${item.status}`}>{item.status}</span>{item.approval_status&&<span className={`approvalTag ${item.approval_status}`}>{item.approval_status}</span>}</div><h3>{item.title}</h3><p>{item.company||'No company'} · {item.module||item.industry||'General'} · {item.location||'India'}</p><small>{item.reference_code||'No reference'} · {item.openings||1} opening(s)</small></div><div className="adminActions"><button onClick={()=>editJob(item)}>Edit</button><button onClick={()=>removeJob(item.id)}>Delete</button>{item.approval_status==='pending'&&<><button onClick={()=>updateJobApproval(item.id,'approved')}>Approve</button><button onClick={()=>updateJobApproval(item.id,'rejected')}>Reject</button></>}</div></article>)}</div></section>}{tab==='applications'&&<section className="applicationsList"><h2>Candidate applications</h2>{applications.length===0?<p>No applications yet.</p>:applications.map(app=><article className="applicationRow" key={app.id}><div><span className={`status ${app.status}`}>{app.status}</span><h3>{app.full_name}</h3><p>{app.jobs?.title||'Unknown requirement'} · {app.email} {app.phone?`· ${app.phone}`:''}</p><p>{app.cover_letter||'No cover note provided.'}</p>{app.resume_url?.startsWith('storage:') ? <a href={`/api/resumes?path=${encodeURIComponent(app.resume_url)}`} target="_blank" rel="noreferrer">Open uploaded resume ↗</a> : app.resume_url && <a href={app.resume_url} target="_blank" rel="noreferrer">Open resume ↗</a>}{app.linkedin_url&&<a href={app.linkedin_url} target="_blank" rel="noreferrer">LinkedIn ↗</a>}</div><select value={app.status} onChange={e=>setApplicationStatus(app.id,e.target.value)}><option value="new">New</option><option value="reviewing">Reviewing</option><option value="shortlisted">Shortlisted</option><option value="rejected">Rejected</option><option value="hired">Hired</option></select></article>)}</section>}{tab==='employers'&&<section className="applicationsList"><h2>Employer accounts</h2>{employers.length===0?<p>No employer registrations yet.</p>:employers.map(employer=><article className="applicationRow" key={employer.id}><div><span className={`approvalTag ${employer.employer_status}`}>{employer.employer_status}</span><h3>{employer.company_name||'Unnamed company'}</h3><p>{employer.full_name||'No contact name'} {employer.phone?`· ${employer.phone}`:''}</p>{employer.company_website&&<a href={employer.company_website} target="_blank" rel="noreferrer">Company website ↗</a>}<small>Registered {new Date(employer.created_at).toLocaleDateString()}</small></div><select value={employer.employer_status} onChange={e=>setEmployerStatus(employer.id,e.target.value)}><option value="pending">Pending</option><option value="approved">Approve</option><option value="rejected">Reject</option></select></article>)}</section>}</main>
}
