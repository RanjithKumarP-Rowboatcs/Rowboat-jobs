'use client'

import { FormEvent, useEffect, useState } from 'react'
import { createClient } from '../../lib/supabase/browser'

const blank = { title: '', company: '', module: '', industry: 'Information Technology', location: 'India', experience: '', type: 'Full-time', openings: 1, salary: '', description: '', requirements: '', responsibilities: '', skills: '', apply_email: 'ranjith@rowboatcs.com', reference_code: '' }
type Job = any

export default function EmployerPage() {
  const [profile, setProfile] = useState<any>(null)
  const [jobs, setJobs] = useState<Job[]>([])
  const [applications, setApplications] = useState<any[]>([])
  const [job, setJob] = useState<any>(blank)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)

  async function load() {
    const me = await fetch('/api/profile', { cache: 'no-store' })
    const body = await me.json()
    if (!me.ok) { location.href = '/login'; return }
    if (body.role !== 'employer') { location.href = body.role === 'candidate' ? '/candidate' : '/admin'; return }
    setProfile(body.profile)
    const jobsResponse = await fetch('/api/jobs?mine=1', { cache: 'no-store' })
    const jobsBody = await jobsResponse.json()
    if (jobsResponse.ok) setJobs(jobsBody.jobs || [])
    if (body.profile?.employer_status === 'approved') {
      const appResponse = await fetch('/api/applications?mine=1', { cache: 'no-store' })
      const appBody = await appResponse.json()
      if (appResponse.ok) setApplications(appBody.applications || [])
    }
  }

  useEffect(() => { load() }, [])

  async function saveProfile(event: FormEvent) {
    event.preventDefault(); setError(''); setMessage('')
    const r = await fetch('/api/profile', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(profile) })
    const b = await r.json(); if (!r.ok) setError(b.error || 'Unable to save profile'); else setMessage('Employer profile updated.')
  }

  async function saveJob(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError(''); setMessage('')
    const payload = { ...job, openings: Number(job.openings) || 1, skills: String(job.skills || '').split(',').map((s: string) => s.trim()).filter(Boolean) }
    const r = await fetch(editingId ? `/api/jobs/${editingId}` : '/api/jobs', { method: editingId ? 'PATCH' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    const b = await r.json()
    if (!r.ok) setError(b.error || 'Unable to save requirement')
    else { setMessage('Requirement saved and sent for admin review. It will become public after approval.'); setJob(blank); setEditingId(null); await load() }
    setBusy(false)
  }

  function edit(item: Job) { setEditingId(item.id); setJob({ ...item, skills: (item.skills || []).join(', ') }); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  async function remove(id: string) { if (!confirm('Delete this requirement?')) return; await fetch(`/api/jobs/${id}`, { method: 'DELETE' }); await load() }
  async function setApplicationStatus(id: string, status: string) { await fetch(`/api/applications/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) }); await load() }
  async function signOut() { const supabase = createClient(); await supabase.auth.signOut(); location.href = '/' }

  const approved = profile?.employer_status === 'approved'

  return <main className="portalShell"><header className="portalHeader"><a href="/"><img src="/rowboat-logo.svg" alt="ROWBOAT CONSULTING SERVICES" /></a><div><a className="portalHeaderLink" href="/opportunities">Public jobs</a><button onClick={signOut}>Sign out</button></div></header><section className="dashboardWrap"><div className="dashboardHero"><div><div className="eyebrow">EMPLOYER PORTAL</div><h1>Build your talent pipeline.</h1><p>Post requirements, manage your roles and review candidates from one workspace.</p></div><span className={`portalBadge ${approved ? 'approved' : 'pending'}`}>{approved ? 'Employer approved' : 'Approval pending'}</span></div>{!approved && <div className="portalNotice"><strong>Your employer account is awaiting admin approval.</strong><span>You can complete your company profile now. Once approved, you can submit requirements for publication.</span></div>}<div className="portalGrid"><section className="portalPanel"><h2>Company profile</h2><form className="portalForm" onSubmit={saveProfile}><label>Company name<input value={profile?.company_name || ''} onChange={e => setProfile({ ...profile, company_name: e.target.value })} /></label><label>Company website<input value={profile?.company_website || ''} onChange={e => setProfile({ ...profile, company_website: e.target.value })} placeholder="https://..." /></label><label>Contact name<input value={profile?.full_name || ''} onChange={e => setProfile({ ...profile, full_name: e.target.value })} /></label><label>Phone<input value={profile?.phone || ''} onChange={e => setProfile({ ...profile, phone: e.target.value })} /></label>{error && <div className="portalMessage error">{error}</div>}{message && <div className="portalMessage">{message}</div>}<button className="portalButton">Save profile →</button></form></section><section className="portalPanel"><div className="panelHeading"><h2>Post a requirement</h2>{editingId && <button type="button" onClick={() => { setEditingId(null); setJob(blank) }}>Cancel edit</button>}</div><form className="portalForm" onSubmit={saveJob}><label>Job title<input required disabled={!approved} value={job.title} onChange={e => setJob({ ...job, title: e.target.value })} placeholder="SAP FICO Consultant" /></label><div className="portalTwo"><label>Module / category<input disabled={!approved} value={job.module} onChange={e => setJob({ ...job, module: e.target.value })} placeholder="SAP FICO" /></label><label>Industry<select disabled={!approved} value={job.industry} onChange={e => setJob({ ...job, industry: e.target.value })}><option>Information Technology</option><option>Manufacturing</option></select></label></div><div className="portalTwo"><label>Location<input disabled={!approved} value={job.location} onChange={e => setJob({ ...job, location: e.target.value })} /></label><label>Experience<input disabled={!approved} value={job.experience} onChange={e => setJob({ ...job, experience: e.target.value })} placeholder="5–8 years" /></label></div><div className="portalTwo"><label>Type<select disabled={!approved} value={job.type} onChange={e => setJob({ ...job, type: e.target.value })}><option>Full-time</option><option>Contract</option><option>Part-time</option><option>Remote</option></select></label><label>Openings<input disabled={!approved} type="number" min="1" value={job.openings} onChange={e => setJob({ ...job, openings: e.target.value })} /></label></div><label>Reference code<input disabled={!approved} value={job.reference_code} onChange={e => setJob({ ...job, reference_code: e.target.value })} placeholder="EMP-001" /></label><label>Skills <small>comma separated</small><input disabled={!approved} value={job.skills} onChange={e => setJob({ ...job, skills: e.target.value })} /></label><label>Short description<textarea disabled={!approved} rows={4} value={job.description} onChange={e => setJob({ ...job, description: e.target.value })} /></label><label>Requirements<textarea disabled={!approved} rows={5} value={job.requirements} onChange={e => setJob({ ...job, requirements: e.target.value })} /></label><label>Responsibilities<textarea disabled={!approved} rows={5} value={job.responsibilities} onChange={e => setJob({ ...job, responsibilities: e.target.value })} /></label><label>Application email<input disabled={!approved} type="email" value={job.apply_email} onChange={e => setJob({ ...job, apply_email: e.target.value })} /></label><button className="portalButton" disabled={!approved || busy}>{busy ? 'Submitting…' : editingId ? 'Resubmit requirement →' : 'Submit for admin review →'}</button></form></section></div><section className="portalPanel"><div className="panelHeading"><h2>Your requirements</h2><span>{jobs.length}</span></div>{jobs.length === 0 ? <div className="portalEmpty"><strong>No requirements yet.</strong><span>Approved employers can submit a requirement above.</span></div> : <div className="dashboardList">{jobs.map(item => <article key={item.id}><div><span className={`status ${item.status}`}>{item.approval_status || 'approved'}</span><h3>{item.title}</h3><p>{item.industry || 'Industry'} · {item.location || 'India'} · {item.openings || 1} opening(s)</p></div><div className="portalActions"><button onClick={() => edit(item)}>Edit</button><button onClick={() => remove(item.id)}>Delete</button></div></article>)}</div>}</section><section className="portalPanel"><h2>Applications to your jobs</h2>{applications.length === 0 ? <div className="portalEmpty"><strong>No applications yet.</strong><span>Candidate applications will appear here once your approved jobs are live.</span></div> : <div className="dashboardList">{applications.map(app => <article key={app.id}><div><span className={`status ${app.status}`}>{app.status}</span><h3>{app.full_name}</h3><p>{app.jobs?.title || 'Job'} · {app.email} {app.phone ? `· ${app.phone}` : ''}</p>{app.resume_url?.startsWith('storage:') ? <a href={`/api/resumes?path=${encodeURIComponent(app.resume_url)}`} target="_blank" rel="noreferrer">Open uploaded resume ↗</a> : app.resume_url && <a href={app.resume_url} target="_blank" rel="noreferrer">Open resume ↗</a>}</div><select value={app.status} onChange={e => setApplicationStatus(app.id, e.target.value)}><option value="new">New</option><option value="reviewing">Reviewing</option><option value="shortlisted">Shortlisted</option><option value="rejected">Rejected</option><option value="hired">Hired</option></select></article>)}</div>}</section></section></main>
}
