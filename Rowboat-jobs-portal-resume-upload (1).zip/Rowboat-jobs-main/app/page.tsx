'use client'

import { useEffect, useMemo, useState, type FormEvent } from 'react'

type Job = {
  id: string
  title: string
  company?: string
  module?: string
  industry?: string
  location?: string
  experience?: string
  type?: string
  openings?: number
  description?: string
  skills?: string[]
}

const industries = [
  ['Information Technology', 'Software, cloud, AI, data, cybersecurity, infrastructure and digital roles.'],
  ['Manufacturing', 'Production, quality, operations, maintenance, engineering and supply chain.'],
]

const services = [
  ['01', 'Consulting', 'Business, technology and transformation support built around practical outcomes.'],
  ['02', 'Talent Solutions', 'Recruitment and specialist talent support for technology and business teams.'],
  ['03', 'Specialist Services', 'Focused expertise for delivery, systems, integration and operational needs.'],
]

export default function Home() {
  const [query, setQuery] = useState('')
  const [industry, setIndustry] = useState('All industries')
  const [jobs, setJobs] = useState<Job[]>([])
  const [loadingJobs, setLoadingJobs] = useState(true)

  useEffect(() => {
    fetch('/api/jobs', { cache: 'no-store', headers: { Accept: 'application/json' } })
      .then(response => response.ok ? response.json() : { jobs: [] })
      .then(body => setJobs(body.jobs || []))
      .catch(() => setJobs([]))
      .finally(() => setLoadingJobs(false))
  }, [])

  const visibleJobs = useMemo(() => jobs.filter(job => {
    const haystack = [
      job.title, job.company, job.module, job.industry, job.location,
      job.experience, job.description, ...(job.skills || []),
    ].filter(Boolean).join(' ').toLowerCase()
    return (!query || haystack.includes(query.toLowerCase())) &&
      (industry === 'All industries' || job.industry === industry)
  }), [jobs, query, industry])

  function handleContactSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const subject = `ROWBOAT website enquiry — ${String(form.get('interest') || '')}`
    const body = `Name: ${String(form.get('name') || '')}\nEmail: ${String(form.get('email') || '')}\nInterest: ${String(form.get('interest') || '')}\n\nMessage:\n${String(form.get('message') || '')}`
    window.location.href = `mailto:ranjith@rowboatcs.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  }

  return (
    <>
      <nav className="nav">
        <div className="container navInner">
          <a className="brand" href="#top" aria-label="ROWBOAT Consulting Services home">
            <img className="brandLogo" src="/rowboat-logo.svg" alt="ROWBOAT CONSULTING SERVICES" />
          </a>
          <div className="navLinks">
            <a href="#services">Consulting</a>
            <a href="#opportunities">Opportunities</a>
            <a href="#industries">Industries</a>
            <a href="#about">About</a>
            <a href="#contact">Contact</a>
            <a className="portalNav" href="/login">Login</a>
            <a className="navCta" href="#contact">Contact ↗</a>
          </div>
          <a className="mobileMenu" href="/login">Login</a>
        </div>
      </nav>

      <main id="top">
        <section className="jobsHero">
          <div className="heroBackdrop" />
          <div className="container jobsHeroInner">
            <div>
              <div className="eyebrow">Consulting · Talent · Technology · India</div>
              <h1>Technology.<br /><em>People.</em><br />Better outcomes.</h1>
              <p>ROWBOAT CONSULTING SERVICES helps organizations solve business and technology needs while helping professionals discover relevant opportunities.</p>
              <div className="heroActions">
                <a className="btn btnPrimary" href="#services">Explore services →</a>
                <a className="textButton" href="/opportunities">Find opportunities ↗</a>
              </div>
            </div>
            <div className="heroPanel">
              <div className="panelKicker">ROWBOAT / CONSULTING SERVICES</div>
              <div className="heroPanelTitle">Advise.<br />Build.<br /><strong>Connect.</strong></div>
              <div className="heroLines"><span /><span /><span /><span /><span /></div>
              <div className="heroPanelBottom"><span>INDIA FIRST</span><span>BUSINESS + TECHNOLOGY</span><span>ONE PLATFORM</span></div>
            </div>
          </div>
        </section>

        <section className="section" id="services">
          <div className="container">
            <div className="sectionHead">
              <div>
                <div className="eyebrow">What we do</div>
                <h2>Consulting services with a practical edge.</h2>
              </div>
              <p>We combine consulting, talent solutions and specialist delivery support so organizations can move from requirement to execution with less friction.</p>
            </div>
            <div className="serviceGrid">
              {services.map(([number, title, text]) => (
                <article className="serviceCard" key={title}>
                  <span>{number}</span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                  <a href="#contact">Discuss your need →</a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="searchSection" id="opportunities">
          <div className="container">
            <div className="eyebrow">Live opportunities</div>
            <h2>Find an opportunity that fits you.</h2>
            <p className="sectionLead">Published jobs are pulled live from the same platform used by the Rowboat admin team. Employers can submit requirements for review, and approved jobs appear here automatically.</p>
            <div className="searchBar">
              <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Job title, skill, company or location" aria-label="Search opportunities" />
              <select value={industry} onChange={e => setIndustry(e.target.value)} aria-label="Filter by industry">
                <option>All industries</option>
                {industries.map(([name]) => <option key={name}>{name}</option>)}
              </select>
              <a className="btn btnPrimary" href="/opportunities">View all jobs →</a>
            </div>

            <div className="homeJobs">
              <div className="resultsHeader">
                <strong>{visibleJobs.length} current opening{visibleJobs.length === 1 ? '' : 's'}</strong>
                <span>Live from Rowboat's recruitment platform.</span>
              </div>
              {loadingJobs && <div className="emptyState">Loading current openings…</div>}
              {!loadingJobs && visibleJobs.length === 0 && (
                <div className="emptyState">No openings match the current filters. <a href="/opportunities">Open the full opportunities page →</a></div>
              )}
              {!loadingJobs && visibleJobs.slice(0, 3).map(job => (
                <article className="homeJobCard" key={job.id}>
                  <div>
                    <span className="jobIndustry">{job.module || job.industry || 'Opportunity'}</span>
                    <h3>{job.title}</h3>
                    <p>{job.company || 'Rowboat opportunity'} · {job.location || 'India'} · {job.experience || 'Experience as specified'}</p>
                  </div>
                  <a href="/opportunities">View &amp; apply →</a>
                </article>
              ))}
              {!loadingJobs && visibleJobs.length > 3 && (
                <div className="homeJobMore">Showing 3 of {visibleJobs.length} live openings. <a href="/opportunities">View all opportunities →</a></div>
              )}
            </div>
          </div>
        </section>

        <section className="section lightSection" id="industries">
          <div className="container">
            <div className="sectionHead">
              <div>
                <div className="eyebrow">Industries</div>
                <h2>Focused where expertise matters.</h2>
              </div>
              <p>We currently publish recruitment opportunities in Information Technology and Manufacturing, with consulting support designed to grow beyond those initial sectors.</p>
            </div>
            <div className="industryGrid">
              {industries.map(([title, text], index) => (
                <article className="industry" key={title}>
                  <span>{String(index + 1).padStart(2, '0')}</span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                  <a href="/opportunities">Explore opportunities →</a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="about">
          <div className="container aboutIntro">
            <div>
              <div className="eyebrow">About Rowboat</div>
              <h2>One company. Two connected needs.</h2>
            </div>
            <p>Organizations need dependable consulting and talent. Professionals need relevant opportunities and clear information. ROWBOAT CONSULTING SERVICES is building a platform that connects those needs through practical consulting, specialist services and a focused opportunity marketplace.</p>
          </div>
          <div className="valueGrid">
            <article><b>01</b><h3>Practical</h3><p>Clear recommendations, focused execution and measurable next steps.</p></article>
            <article><b>02</b><h3>Relevant</h3><p>Match solutions and opportunities to the real need, not the buzzword.</p></article>
            <article><b>03</b><h3>Transparent</h3><p>Present requirements, services and next actions clearly.</p></article>
            <article><b>04</b><h3>India first</h3><p>Build in India while creating a platform that can scale wider.</p></article>
          </div>
        </section>

        <section className="darkSection" id="employers">
          <div className="container employerGrid">
            <div>
              <div className="eyebrow">For employers &amp; organizations</div>
              <h2>Need talent or consulting support?</h2>
              <p>Employer accounts can submit technology and manufacturing requirements for Rowboat admin review. Approved requirements then become part of the live opportunity marketplace.</p>
              <div className="heroActions">
                <a className="btn btnWhite" href="/login">Employer login →</a>
                <a className="textButton lightLink" href="#contact">Talk to Rowboat ↗</a>
              </div>
            </div>
            <div className="employerPoints">
              <span>01</span><strong>Create an employer account</strong>
              <span>02</span><strong>Submit your requirement</strong>
              <span>03</span><strong>Rowboat reviews and publishes</strong>
            </div>
          </div>
        </section>

        <section className="contactSection" id="contact">
          <div className="container">
            <div className="contactIntro">
              <div>
                <div className="eyebrow">Contact Rowboat</div>
                <h2>Let's build the right next step.</h2>
                <p>Tell us whether you need consulting, specialist services, talent solutions or help with an opportunity.</p>
              </div>
              <div className="contactDetails">
                <span>Enquiries</span>
                <a href="mailto:ranjith@rowboatcs.com">ranjith@rowboatcs.com</a>
                <a className="contactPortal" href="/login">Candidate / Employer portal →</a>
              </div>
            </div>
            <form className="contactForm" onSubmit={handleContactSubmit}>
              <label>Name<input name="name" required placeholder="Your name" autoComplete="name" /></label>
              <label>Email<input name="email" type="email" required placeholder="you@company.com" autoComplete="email" /></label>
              <label>I'm interested in<select name="interest"><option>Consulting services</option><option>Talent solutions</option><option>Posting a hiring requirement</option><option>Finding opportunities</option><option>Business partnership</option><option>General enquiry</option></select></label>
              <label>Message<textarea name="message" required rows={5} placeholder="Tell us what you need..." /></label>
              <div className="formActions"><button className="btn btnPrimary" type="submit">Send enquiry ↗</button><span className="formNote">Your enquiry is addressed to ranjith@rowboatcs.com.</span></div>
            </form>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container footerTop">
          <div className="footerBrand"><img className="footerLogo" src="/rowboat-logo.svg" alt="ROWBOAT CONSULTING SERVICES" /></div>
          <div className="footerLinks"><a href="#services">Consulting</a><a href="/opportunities">Opportunities</a><a href="#industries">Industries</a><a href="#about">About</a><a href="#contact">Contact</a><a href="/login">Portal Login</a><a href="/admin">Admin</a></div>
        </div>
        <div className="container footerBottom"><span>© 2026 ROWBOAT CONSULTING SERVICES</span><span>Consulting · Talent Solutions · Specialist Services</span></div>
      </footer>
    </>
  )
}
