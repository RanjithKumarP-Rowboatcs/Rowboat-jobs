import type { Metadata } from 'next'
import './globals.css'
import './brand-overrides.css'
import './opportunities/opportunities.css'
import './admin/admin.css'

export const metadata: Metadata = {
  title: 'ROWBOAT Consulting Services | Consulting, Talent & Opportunities',
  description: 'ROWBOAT Consulting Services — consulting, talent solutions, specialist services and relevant opportunities in India.',
  keywords: ['Rowboat Consulting Services', 'Rowboat Jobs', 'jobs in India', 'careers India', 'employment opportunities', 'IT jobs', 'manufacturing jobs', 'pharma jobs', 'healthcare jobs', 'government jobs India', 'startup jobs'],
  icons: { icon: '/rowboat-mark.svg', apple: '/rowboat-mark.svg' },
  openGraph: { title: 'ROWBOAT Consulting Services | Consulting, Talent & Opportunities', description: 'Every Industry. Every Opportunity. One Platform.', type: 'website' },
  robots: { index: true, follow: true },
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en-IN"><body>{children}</body></html> }
